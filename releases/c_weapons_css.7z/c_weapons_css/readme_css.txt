
Original gmod 13 source files for c_ weapons 
Made by Iñaki

These are the clean files only needed for compiling, there are a lot of steps in the middle to get to the finished product.

If have have trouble fell free to contact me at: https://steamcommunity.com/id/inakistuff/ or my email: dj_inaki@hotmail.com
For more info check this blogpost: http://inakistuff.blogspot.com/2013/08/gmodviewmodels.html

Change notes for codders:
All the weapons that where flipped like the AK since cs 1.6 where flipped to the right side, I dont know if that was needed for bonemerge to work properly.
I still did mirror all of them for consistensy sake, the fingers proportions are still not the same of the hl2 skeleton, but they are very very similar.

You may need to change some events to make them work for your mod.