
Original gmod 13 source files for c_ weapons 
Made by Iñaki

These are the clean files only needed for compiling, there are a lot of steps in the middle to get to the finished product.

If have have trouble fell free to contact me at: https://steamcommunity.com/id/inakistuff/ or my email: dj_inaki@hotmail.com
For more info check this blogpost: http://inakistuff.blogspot.com/2013/08/gmodviewmodels.html

Notes for codders:
The finger proportions are not the same as HL2 but very similar, more than css, the palm helper bone was omited so that may bring some issues if you plan to use the dods arms.
Some weapons have poseparameters to make life easier or harder for coders with anims.