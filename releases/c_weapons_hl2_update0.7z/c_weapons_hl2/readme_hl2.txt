
Original gmod 13 source files for c_ weapons 
Made by Iñaki

These are the clean files only needed for compiling, there are a lot of steps in the middle to get to the finished product.

If have have trouble fell free to contact me at: https://steamcommunity.com/id/inakistuff/ or my email: dj_inaki@hotmail.com
For more info check this blogpost: http://inakistuff.blogspot.com/2013/08/gmodviewmodels.html

Notes for people who care and want to make them better:
The Smg is missing the crosshair
The Crossbow is not compiling
The Crowbar attact end pose is not corresponding to the idle pose(thats from retail but still bugs me)
The Slam bones are very far away instead of being in the center of the weapon and pivot of the flip thingy, that makes the model jerk up when blending from one state of anim to another.
The Stun stick misses the center of the screen in the attach anim because its made for the crowbar.

Changenotes for hl2 retail purists:
The AR2 now has the left arm holding it
The 357 has modeled holes in the barrel and that barrel cap thingy on the right side too to work for mods that center the wep in the screen
The Shotgun barrel is a bit rounder
The Pistol now ejects bullets when it fires fixed from retail
The Crossbow has the wheel from the left also on the right to make it better for widescreens
The 357 has modded anims for reloading one bullet at a time start-loop-end(like the shotgun), a poseparameter that spins the barrel, and a bodygroup for the bullets.

Changes for gmod:
The tool gun coil now spins in the attack anim.
I intended to make an anim for the thumbstick with poseparameters but got cut due to time.